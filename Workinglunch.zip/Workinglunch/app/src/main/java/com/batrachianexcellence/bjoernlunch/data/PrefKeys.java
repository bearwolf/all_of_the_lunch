package com.batrachianexcellence.bjoernlunch.data;

public class PrefKeys {


}
