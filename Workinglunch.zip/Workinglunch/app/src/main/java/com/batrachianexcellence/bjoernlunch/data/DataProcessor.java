package com.batrachianexcellence.bjoernlunch;
import android.content.Context;
import android.content.SharedPreferences;


import com.batrachianexcellence.bjoernlunch.data.PrefKeys;

public class DataProcessor {

    private static Context context;

    public DataProcessor(Context context){
        this.context = context;
    }

    public final static String SHARED_PREFS = "sharedPref";

    public static void setInt( String key, int value) {
        SharedPreferences sharedPref = context.getSharedPreferences(SHARED_PREFS,0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt(key, value);

        editor.apply();
    }

    public static int getInt(String key) {
        SharedPreferences prefs = context.getSharedPreferences(SHARED_PREFS, 0);
        return prefs.getInt(key, 0);
    }

    public static void setStr(String key, String value) {
        SharedPreferences sharedPref = context.getSharedPreferences(SHARED_PREFS,0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public static String getStr(String key) {
        SharedPreferences prefs = context.getSharedPreferences(SHARED_PREFS, 0);
        return prefs.getString(key,"DNF");
    }

    public static void setBool(String key, boolean value) {
        SharedPreferences sharedPref = context.getSharedPreferences(SHARED_PREFS,0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    public static boolean getBool(String key) {
        SharedPreferences prefs = context.getSharedPreferences(SHARED_PREFS, 0);
        return prefs.getBoolean(key,false);
    }
}