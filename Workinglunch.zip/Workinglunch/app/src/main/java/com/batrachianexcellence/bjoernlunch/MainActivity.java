package com.batrachianexcellence.bjoernlunch;

import android.content.Intent;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.support.v7.widget.Toolbar;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.view.ViewGroup.LayoutParams;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.batrachianexcellence.bjoernlunch.DataProcessor;
import com.batrachianexcellence.bjoernlunch.data.FilterLunchItems;
import com.batrachianexcellence.bjoernlunch.data.LunchItems;
import com.batrachianexcellence.bjoernlunch.data.RestaurantRVAdapter;


import java.util.List;
import java.util.Optional;



public class MainActivity extends AppCompatActivity {
    TextView statusText;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;

    public Switch switch1;

    private class BackgroundFetchResult{
        boolean success;
        Optional<List<LunchItems.LunchItem>> maybeItems;
        Optional<Exception> maybeException;

        public BackgroundFetchResult(boolean success, List<LunchItems.LunchItem> items, Exception ex){
            this.success = success;
            this.maybeItems = Optional.ofNullable(items);
            this.maybeException = Optional.ofNullable(ex);
        }
    }

    private class BackgroundFetcher extends AsyncTask<String, Void, BackgroundFetchResult>{

        @Override
        protected BackgroundFetchResult doInBackground(String... urls) {
            try {
                List<LunchItems.LunchItem> res = LunchItems.fetchLunchItems(urls[0]);
                return new BackgroundFetchResult(true, res, null);
            }catch(Exception ex){
                return new BackgroundFetchResult(false, null, ex);
            }
        }

        protected void onPostExecute(BackgroundFetchResult res){
            if(res.success){
                if(res.maybeItems.get().size() == 0){
                    statusText.setText("No items returned");
                }else {
                    statusText.setText(String.format(
                            "fetched items, %d of them", res.maybeItems.get().size()));
                    String searchText = null;//((TextView)findViewById(R.id.txt_search)).getText().toString();
                    CheckBox veganOnly = findViewById(R.id.cb_veganonly);
                    CheckBox searchInRestaurantNames = findViewById(R.id.cb_search_in_restaurant_name);
                    CheckBox searchInMenuItemNames = findViewById(R.id.cb_search_in_food_name);
                    List<LunchItems.Restaurant> filteredRestaurants =
                            FilterLunchItems.filterLunchItems(
                                    res.maybeItems.get().get(0).restaurants,
                                    new FilterLunchItems.FilterOptions(searchText,
                                            veganOnly.isChecked(),
                                            searchInRestaurantNames.isChecked()==false,
                                            searchInMenuItemNames.isChecked()));
                    RestaurantRVAdapter adapter = new RestaurantRVAdapter(filteredRestaurants);
                    recyclerView.setAdapter(adapter);
                }
            }else {
                statusText.setText(String.format(
                        "failed fetch, exception %s", res.maybeException.get().toString()));
            }
        }
    }



            // ----------------------------- ONCREATE STARTS HERE


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        statusText = findViewById(R.id.status_text);
        String url = LunchItems.DEFAULT_URL;
        statusText.setText("fetching from " + url);


        //SettingsActivity.loadData();
        //SettingsActivity.updateViews();
        //((SettingsActivity)getActivity()).loadData();
       // ((SettingsActivity)getCallingActivity()).updateViews();

        new BackgroundFetcher().execute(url);


        findViewById(R.id.cb_veganonly).setOnClickListener((View v) -> {

            statusText.setText("fetching from " + url);
            new BackgroundFetcher().execute(url);


        });
        findViewById(R.id.cb_search_in_restaurant_name).setOnClickListener((View v) -> {

            statusText.setText("fetching from " + url);
            new BackgroundFetcher().execute(url);


        });
        findViewById(R.id.floatingButton).setOnClickListener((View v) -> {

            Intent i = new Intent(MainActivity.this,SettingsActivity.class);
            startActivity(i);


        });
        recyclerView = findViewById(R.id.recycleView);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.optionsmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent i = new Intent(MainActivity.this,SettingsActivity.class);
            startActivity(i);
            return true;
        }
        if (id == R.id.action_about_us) {
            Intent i = new Intent(MainActivity.this,AboutActivity.class);
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
