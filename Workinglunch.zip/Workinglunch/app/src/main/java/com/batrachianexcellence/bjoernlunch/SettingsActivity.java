package com.batrachianexcellence.bjoernlunch;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;

import com.batrachianexcellence.bjoernlunch.DataProcessor;
import com.batrachianexcellence.bjoernlunch.data.PrefKeys;

import static com.batrachianexcellence.bjoernlunch.DataProcessor.SHARED_PREFS;

public class SettingsActivity extends AppCompatActivity {
    SharedPreferences sharedPref;
   // public static final String SHARED_PREFS = "sharedPrefs";
   // public static final String SWITCH1 = "switch1";
   public Switch switch1;
    public static boolean switchOnOff;
   Context mContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        setContentView(R.layout.activity_settings);
        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(mToolbar);

        //statusText = findViewById(R.id.status_text);
       // DataProcessor.getBool(PrefKeys.SWITCH1);
        //updateViews();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        switch1 = (Switch) findViewById(R.id.switch1);

        findViewById(R.id.switch1).setOnClickListener((View v) -> {

            DataProcessor.setBool(SHARED_PREFS, switch1.isChecked());

            //// To Save a value


        });

        }


//    public void saveData(){
//        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//
//        editor.putBoolean(SWITCH1, switch1.isChecked());
//        editor.apply();
//        Toast.makeText(this, "data saved", Toast.LENGTH_SHORT).show();
//    }
//    public void loadData(){
//        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
//        MainActivity.switchOnOff = sharedPreferences.getBoolean(SWITCH1, false);
//    }
    public void updateViews(){
        switch1.setChecked(switchOnOff);
    }
    }



